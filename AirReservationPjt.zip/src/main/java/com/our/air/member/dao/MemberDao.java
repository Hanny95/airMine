package com.our.air.member.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.our.air.member.vo.MemberVo;

@Component
public class MemberDao {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public final static int MEMBER_IS_NOT = 0;
	public final static int MEMBER_IS = 1;
	public final static int MEMBER_ADD_SUCCESS = 2;
	public final static int MEMBER_ADD_FAIL = 3;
	
	
	public int loginMember(MemberVo memberVo) {
		
		System.out.println("[MemberDao] loginMember() INIT!");
		
		int result = 0;
		
		String sql = "SELECT COUNT (*) FROM tbl_member WHERE m_mail =? and m_pw =?";
		
		result = jdbcTemplate.queryForObject(sql, Integer.class, 
											memberVo.getM_mail(),
											memberVo.getM_pw());
				
		return result;
	}


	public boolean isMember(MemberVo memberVo) {
		
		System.out.println("[MemberDao] isMember() INIT!");
		
		int result = 0;
		
		String sql = "SELECT COUNT(*) FROM tbl_member WHERE m_mail =? and m_pw =?";
		
		result = jdbcTemplate.queryForObject(sql, Integer.class, memberVo.getM_mail(), memberVo.getM_pw());
		
		
		return result > 0 ? true : false;
	}


	public int insertMember(MemberVo memberVo) {
		
		System.out.println("[MemberDao] insertMember() INIT!");
		
		int result = 0;
		
		String sql = "INSERT INTO tbl_member(m_mail, m_pw, m_reg_date, m_mod_date)"
				+ " VALUES(?, ?, NOW())";
		
		jdbcTemplate.update(sql, memberVo.getM_mail(), memberVo.getM_pw());
		
		if(result > 0) {
			
			return MEMBER_ADD_SUCCESS;
			
		} else {
			
			return MEMBER_ADD_FAIL;
		}
		
	}
	
	
	

}
