package com.our.air.member.service;

import java.awt.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.our.air.member.dao.MemberDao;
import com.our.air.member.vo.MemberVo;

@Service
public class MemberService {
	
	@Autowired
	MemberDao memberDao;
	
	
	public int loginConfirm(MemberVo memberVo) {
		
		System.out.println("[MemberService] loginConfirm() INIT!");
		
		int result = memberDao.loginMember(memberVo);
		
		
		return result;
	}


	public int joinMember(MemberVo memberVo) {
		
		System.out.println("[MemberService] joinMember() INIT!");
		
		if (memberDao.isMember(memberVo)) {
			
			return MemberDao.MEMBER_IS;
			
		} else {
			
			return memberDao.insertMember(memberVo);
		}
		
	}

}

