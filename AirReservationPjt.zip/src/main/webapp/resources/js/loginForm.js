function loginFun() {

	console.log('loginFun() INIT!');
	
	var loginForm = document.loginForm;
	
	if(loginForm.m_mail.value == "") {
	
		alert("Please input mail address!!");
		loginForm.m_mail.focus();
		
	} else if (loginForm.m_pw.value == "") {
	
		alert("Please input password!!");
		loginForm.m_pw.focus();
	
	} else {
	
		loginForm.submit(); 
		
	}
}